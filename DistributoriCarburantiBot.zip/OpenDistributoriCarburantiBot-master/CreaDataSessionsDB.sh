sqlite3 DataSessionsDB_temp < CreaDataSessionsDB.txt
mv DataSessionsDB_temp DataSessionsDB

