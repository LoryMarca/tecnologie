#!/bin/bash
php -c /etc/php5/apache2 -f start.php getupdates
