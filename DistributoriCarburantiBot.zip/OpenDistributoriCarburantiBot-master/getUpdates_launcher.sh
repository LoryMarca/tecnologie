#!/bin/bash
#
# >>>>>>> !!! Substitute <BASE_PATH> with the right path in your environment: for example /var/www/html !!! <<<<<<
#
php -c /etc/php5/apache2 -f <BASE_PATH>/Telegram/OpenDistributoriCarburantiBot/start.php getupdates

